# text to voice generator

A Pen created on CodePen.

Original URL: [https://codepen.io/Noor-Ul-Aien/pen/yyLKMxp](https://codepen.io/Noor-Ul-Aien/pen/yyLKMxp).

