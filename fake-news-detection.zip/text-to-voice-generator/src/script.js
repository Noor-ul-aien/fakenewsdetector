function analyzeNews() {
    let news = document.getElementById("newsInput").value;
    let resultDiv = document.getElementById("result");
    let analysisDiv = document.getElementById("analysis");
    
    if (news.trim() === "") {
        resultDiv.innerHTML = "⚠️ Please enter a news article.";
        analysisDiv.innerHTML = "";
        return;
    }
    
    let { isFake, analysis } = detectFakeNews(news);
    
    if (isFake) {
        resultDiv.innerHTML = "🚨 Fake News Detected!";
        resultDiv.style.color = "red";
    } else {
        resultDiv.innerHTML = "✅ Real News!";
        resultDiv.style.color = "green";
    }
    
    analysisDiv.innerHTML = analysis;
}

function detectFakeNews(news) {
    let fakeIndicators = ["shocking", "secret", "exposed", "cover-up", "hidden", "unbelievable"];
    let hasFakeWords = fakeIndicators.some(word => news.toLowerCase().includes(word));
    let lacksSource = !/(bbc|cnn|reuters|nasa|who|un)/i.test(news);
    let falseClaims = /alien|cure for all diseases|government experiment|mind control/i.test(news);
    
    let analysis = "<strong>Analysis:</strong><br>";
    let isFake = false;
    
    if (hasFakeWords) {
        analysis += "❌ Sensational words detected (e.g., 'shocking', 'secret', 'unbelievable').<br>";
        isFake = true;
    }
    if (lacksSource) {
        analysis += "❌ No credible sources mentioned (e.g., BBC, CNN, Reuters).<br>";
        isFake = true;
    }
    if (falseClaims) {
        analysis += "❌ Contains scientifically or logically incorrect claims.<br>";
        isFake = true;
    }
    if (!isFake) {
        analysis += "✅ Contains reliable sources and factual information.<br>✅ Language is neutral and non-sensational.<br>✅ Claims are logical and verifiable.";
    }
    
    return { isFake, analysis };
}
